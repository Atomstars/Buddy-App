import React from 'react';
import { Home, LineChart, Target, CalendarDays, Compass, CheckSquare, BrainCircuit, Rocket, CalendarClock, Wallet } from 'lucide-react';
import { motion } from 'framer-motion';

const getTabsForService = (service) => {
  if (service === 'budget') {
    return [
      { id: 'home', label: 'Home', icon: Home },
      { id: 'analytics', label: 'Analytics', icon: LineChart },
      { id: 'investing', label: 'Investing', icon: Rocket, isPremium: true },
      { id: 'transactions', label: 'Recent', icon: Wallet }
    ];
  }
  if (service === 'schedule') {
    return [
      { id: 'home', label: 'Home', icon: CalendarDays },
      { id: 'analytics', label: 'Insights', icon: Target },
      { id: 'recent', label: 'History', icon: CheckSquare },
      { id: 'smart', label: 'Smart AI', icon: CalendarClock, isPremium: true }
    ];
  }
  if (service === 'manifest') {
    return [
      { id: 'home', label: 'Visions', icon: Compass },
      { id: 'plan', label: 'Plan', icon: Target, isPremium: true },
      { id: 'ai', label: 'Vision AI', icon: BrainCircuit, isPremium: true },
      { id: 'milestones', label: 'Milestones', icon: CheckSquare, isPremium: true }
    ];
  }
  return [];
};

export const Taskbar = ({ activeService, activeTab, onTabSelect }) => {
  const tabs = getTabsForService(activeService);

  if (!tabs.length) return null;

  return (
    <nav className="taskbar">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            className={`taskbar-item ${isActive ? 'active' : ''}`}
            onClick={() => onTabSelect(tab.id)}
            style={{ position: 'relative' }}
          >
            {tab.isPremium && (
              <span className="premium-badge-floating">Premium</span>
            )}
            <motion.div whileTap={{ scale: 0.9 }}>
              <Icon size={22} strokeWidth={isActive ? 2.5 : 2} color={tab.isPremium ? 'var(--gold)' : undefined} style={tab.isPremium ? { filter: 'drop-shadow(0 0 8px rgba(255,215,0,0.6))' } : undefined} />
            </motion.div>
            <span style={{ marginTop: 4, color: tab.isPremium ? 'var(--gold)' : undefined, textShadow: tab.isPremium ? '0 0 10px rgba(255,215,0,0.4)' : undefined }}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
